import React from 'react';

export default function worker() {
  return (
   <div>
       <h1> i am the worker</h1>
   </div>
  );
}
