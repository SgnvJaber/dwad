import React from 'react';

export default function home() {
  return (
   <div>
       <h1> this is the homepage</h1>
   </div>
  );
}
