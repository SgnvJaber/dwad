import React from 'react';

export default function schedule() {
  return (
   <div>
       <h1> i am the schedule</h1>
   </div>
  );
}
