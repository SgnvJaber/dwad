import React from 'react';

export default function about() {
  return (
   <div>
       <h1> this is the about page</h1>
   </div>
  );
}
