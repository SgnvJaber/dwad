import React from 'react';

export default function finance() {
  return (
   <div>
       <h1> i am the finance</h1>
   </div>
  );
}
